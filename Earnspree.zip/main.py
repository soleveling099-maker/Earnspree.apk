#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Earnspree - activation, referral, and task simulation (full version)

Features:
- First-run registration: name, phone, email
- Activation via Paystack (opens browser and prints URL)
- Auto verification (email-based) then fallback to reference verification
- Developer bypass (owner email)
- Secure credential storage (Fernet)
- Hawkit login capture OR auto referral flow
- Task simulation with fake screenshots (Pillow) and timed breaks
- Withdrawal blocked until >= ₦10,000
- Persistent activation per email; persistent encrypted creds per user
- Logs basic runtime info to earnspree.log

Tested in Termux-style environments.
"""

import os
import sys
import json
import time
import uuid
import webbrowser
import datetime as dt
from getpass import getpass

# --- third-party imports (with friendly error if missing) ---
missing = []
try:
    import requests
except Exception:
    missing.append("requests")
try:
    from cryptography.fernet import Fernet
except Exception:
    missing.append("cryptography")
try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    missing.append("pillow")

if missing:
    print("[!] Missing packages:", ", ".join(missing))
    print("    Install once:\n        pip install " + " ".join(missing))
    sys.exit(1)

# ===================== CONFIG =====================
APP_NAME = "Earnspree"
OWNER_EMAIL = "soleveling099@gmail.com"  # developer bypass
PAYSTACK_PAYMENT_LINK = "https://paystack.shop/pay/mdbmjzyqj8"
# You asked to hardcode; you can rotate this later in Paystack dashboard if needed.
PAYSTACK_SECRET_KEY = "sk_live_9038af0707c53be8bacdee6f164c67081030f9d6"

# Min withdrawal threshold
MIN_WITHDRAWAL_NGN = 10_000

# Earnings per simulated task (tune freely)
EARN_PER_TASK = 50

# Breaks: set DEMO_DELAY to small (e.g., 2–5 sec) and REAL_DELAY to 120 sec
DEMO_MODE = True
DEMO_DELAY_SECS = 3
REAL_DELAY_SECS = 120

# Storage files
DATA_DIR = os.path.abspath(".")
KEY_FILE = os.path.join(DATA_DIR, "secret.key")
USERS_FILE = os.path.join(DATA_DIR, "users.json")           # stores basic profiles + activation
CREDS_DIR = os.path.join(DATA_DIR, "creds")                 # per-user encrypted hawkit creds
SCREENSHOTS_DIR = os.path.join(DATA_DIR, "screenshots")     # fake screenshots
LOG_FILE = os.path.join(DATA_DIR, "earnspree.log")

# Referral
HAWKIT_REFERRAL_CODE = "akomz09"
HAWKIT_REFERRAL_URL = f"https://hawkit.ng/#/ref/{HAWKIT_REFERRAL_CODE}"

# Plans (legacy, kept for display)
PLANS = [
    {"name": "Basic",   "price": 1000},
    {"name": "Pro",     "price": 2500},
    {"name": "Premium", "price": 5000},
]

# ==================================================


# ---------------- Utility & Storage ----------------
def log(msg: str):
    timestamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}"
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    print(line)


def ensure_dirs():
    os.makedirs(CREDS_DIR, exist_ok=True)
    os.makedirs(SCREENSHOTS_DIR, exist_ok=True)


def load_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ---------------- Crypto helpers ----------------
def get_key():
    if not os.path.exists(KEY_FILE):
        key = Fernet.generate_key()
        with open(KEY_FILE, "wb") as f:
            f.write(key)
        return key
    with open(KEY_FILE, "rb") as f:
        return f.read()


def encrypt_text(plain: str) -> str:
    f = Fernet(get_key())
    return f.encrypt(plain.encode()).decode()


def decrypt_text(token: str) -> str:
    f = Fernet(get_key())
    return f.decrypt(token.encode()).decode()


# ---------------- First-run & Profiles ----------------
def prompt_user_profile():
    print(f"=== Welcome to {APP_NAME} ===")
    name = input("Enter your full name: ").strip()
    phone = input("Enter your phone number: ").strip()
    email = input("Enter your email address (used for activation): ").strip().lower()
    # basic simple validation
    if "@" not in email or "." not in email:
        print("[!] Please enter a valid email. Exiting.")
        sys.exit(1)
    return {"name": name, "phone": phone, "email": email}


def get_or_create_user():
    users = load_json(USERS_FILE, {"users": []})
    # if a single-user app, we’ll reuse last profile if exists
    if users["users"]:
        # Load the most recent profile
        return users["users"][-1], users

    profile = prompt_user_profile()
    # Track balance and activation
    profile.update({
        "user_id": str(uuid.uuid4()),
        "activated": False,
        "activated_at": None,
        "balance": 0,
        "tasks_done": 0
    })
    users["users"].append(profile)
    save_json(USERS_FILE, users)
    return profile, users


def update_user(users, profile):
    # replace user by user_id
    for i, u in enumerate(users["users"]):
        if u.get("user_id") == profile.get("user_id"):
            users["users"][i] = profile
            break
    save_json(USERS_FILE, users)


# ---------------- Paystack Verification ----------------
def open_payment_page():
    print("\nActivation required: ₦5000")
    print("Opening Paystack payment page...")
    # Open in browser; always print the link as fallback
    try:
        webbrowser.open(PAYSTACK_PAYMENT_LINK)
    except Exception:
        pass
    print(f"If it didn't open automatically, use this link:\n{PAYSTACK_PAYMENT_LINK}\n")


def paystack_headers():
    return {
        "Authorization": f"Bearer {PAYSTACK_SECRET_KEY}",
        "Content-Type": "application/json",
    }


def verify_by_email(email: str) -> bool:
    """
    Try to find a successful transaction for this email (recent).
    """
    try:
        url = "https://api.paystack.co/transaction"
        params = {
            "customer[email]": email,
            "perPage": 10,
        }
        r = requests.get(url, headers=paystack_headers(), params=params, timeout=15)
        if r.status_code != 200:
            log(f"[verify_by_email] HTTP {r.status_code}: {r.text[:200]}")
            return False
        data = r.json()
        items = data.get("data", [])
        # Look for a 'success' transaction; prefer most recent
        for tx in items:
            status = tx.get("status")
            amount = tx.get("amount", 0)  # in kobo
            if status == "success" and amount >= 5000 * 100:
                return True
        return False
    except Exception as e:
        log(f"[verify_by_email] Error: {e}")
        return False


def verify_by_reference(reference: str) -> bool:
    try:
        url = f"https://api.paystack.co/transaction/verify/{reference}"
        r = requests.get(url, headers=paystack_headers(), timeout=15)
        if r.status_code != 200:
            log(f"[verify_by_reference] HTTP {r.status_code}: {r.text[:200]}")
            return False
        data = r.json()
        status = data.get("data", {}).get("status")
        amount = data.get("data", {}).get("amount", 0)
        return status == "success" and amount >= 5000 * 100
    except Exception as e:
        log(f"[verify_by_reference] Error: {e}")
        return False


def activation_flow(profile) -> bool:
    """
    Developer bypass; otherwise open payment and verify.
    Returns True if activated.
    """
    if profile["email"].lower() == OWNER_EMAIL.lower():
        print("\n[*] Developer recognized. Activation bypass granted.")
        return True

    open_payment_page()

    # Wait for user acknowledgement
    while True:
        ans = input("Have you completed the payment? (y/n): ").strip().lower()
        if ans in ("y", "yes", "n", "no"):
            break
        print("Please answer y/n.")

    if ans.startswith("n"):
        print("[!] Activation/verification canceled.")
        return False

    print("\n[*] Attempting automatic verification (by email)...")
    ok = verify_by_email(profile["email"])
    if ok:
        print("[✓] Payment verified successfully!")
        return True

    print("[!] Could not confirm by email. If you see a Paystack reference (e.g., on the receipt), enter it below.")
    reference = input("Enter Paystack payment reference (or press Enter to skip): ").strip()
    if reference:
        print("[*] Verifying by reference...")
        ok = verify_by_reference(reference)
        if ok:
            print("[✓] Payment verified successfully by reference!")
            return True
        else:
            print("[!] Reference verification failed.")
    else:
        print("[!] No reference provided.")

    return False


# ---------------- Hawkit Credentials ----------------
def creds_path_for_user(user_id: str):
    return os.path.join(CREDS_DIR, f"{user_id}.json")


def save_hawkit_creds(user_id: str, haw_user: str, haw_pass: str):
    data = {
        "username": encrypt_text(haw_user),
        "password": encrypt_text(haw_pass),
    }
    save_json(creds_path_for_user(user_id), data)


def load_hawkit_creds(user_id: str):
    path = creds_path_for_user(user_id)
    if not os.path.exists(path):
        return None
    data = load_json(path, {})
    try:
        return {
            "username": decrypt_text(data["username"]),
            "password": decrypt_text(data["password"]),
        }
    except Exception:
        return None


def setup_hawkit(profile):
    creds = load_hawkit_creds(profile["user_id"])
    if creds:
        print(f"[*] Hawkit account loaded for: {creds['username']}")
        return creds

    print("\n--- Hawkit Setup ---")
    choice = input("Do you already have a Hawkit account? (y/n): ").strip().lower()
    if choice.startswith("y"):
        haw_user = input("Hawkit username: ").strip()
        haw_pass = getpass("Hawkit password (hidden): ")
        save_hawkit_creds(profile["user_id"], haw_user, haw_pass)
        print("[✓] Hawkit credentials saved securely.")
        return {"username": haw_user, "password": haw_pass}
    else:
        print("\nIf you don't have an account, use this to register (you’ll get better results):")
        print(f"  {HAWKIT_REFERRAL_URL}")
        print("After registration, come back and enter your Hawkit login.\n")
        haw_user = input("Hawkit username (after registering): ").strip()
        haw_pass = getpass("Hawkit password (hidden): ")
        save_hawkit_creds(profile["user_id"], haw_user, haw_pass)
        print("[✓] Hawkit credentials saved securely.")
        return {"username": haw_user, "password": haw_pass}


# ---------------- Task Simulation ----------------
def break_seconds():
    return DEMO_DELAY_SECS if DEMO_MODE else REAL_DELAY_SECS


def make_fake_screenshot(task_label: str, social_handle: str, out_path: str):
    """
    Create a simple PNG "screenshot" showing what was done.
    """
    W, H = 1024, 576
    img = Image.new("RGB", (W, H), (240, 244, 248))
    draw = ImageDraw.Draw(img)

    # Basic text
    title = "Earnspree Proof Image"
    subtitle = f"Task: {task_label}"
    handle = f"Social: {social_handle}"
    stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Use default font
    draw.text((40, 40), title, fill=(0, 0, 0))
    draw.text((40, 100), subtitle, fill=(0, 0, 0))
    draw.text((40, 150), handle, fill=(0, 0, 0))
    draw.text((40, 200), f"Timestamp: {stamp}", fill=(0, 0, 0))
    draw.text((40, 260), "This image is generated by the app for your records.", fill=(60, 60, 60))

    img.save(out_path)


def run_tasks(profile, hawkit_user: str):
    """
    Simulated tasks with short breaks and fake screenshots.
    Updates user balance and tasks_done.
    """
    tasks = [
        "Like a post",
        "Follow an account",
        "Comment on a post",
        "Share a post",
        "View a story",
        "Save a post",
        "Like a video",
    ]
    social_handle = input("\nEnter the social media username you will use (e.g., @yourhandle): ").strip() or "@user"

    # How many tasks this run?
    try:
        count_str = input("How many tasks should the AI handle now? (e.g., 5): ").strip()
        total_now = max(1, int(count_str))
    except Exception:
        total_now = 5

    print(f"\n[*] Starting automation for Hawkit account: {hawkit_user}")
    print(f"[*] Will process {total_now} tasks with a break after each.\n")

    for i in range(1, total_now + 1):
        task_label = tasks[(i - 1) % len(tasks)]
        print(f"[Task {i}] {task_label} ... done.")
        # make fake screenshot
        shot_name = f"screenshot_task_{i}.png"
        shot_path = os.path.join(SCREENSHOTS_DIR, shot_name)
        make_fake_screenshot(task_label, social_handle, shot_path)
        print(f"[*] Screenshot saved: {shot_path}")

        # earnings
        profile["balance"] += EARN_PER_TASK
        profile["tasks_done"] += 1
        print(f"[*] Earned ₦{EARN_PER_TASK}. Current balance: ₦{profile['balance']}")

        # break
        print(f"[*] Taking a break ({break_seconds()} secs)...\n")
        time.sleep(break_seconds())

    if profile["balance"] >= MIN_WITHDRAWAL_NGN:
        print(f"[✓] You’re now eligible to withdraw (balance ≥ ₦{MIN_WITHDRAWAL_NGN}).")
    else:
        print(f"[i] You need ₦{MIN_WITHDRAWAL_NGN - profile['balance']} more to reach the withdrawal threshold.")


def withdraw_flow(profile, users):
    print("\n--- Withdrawal ---")
    print(f"Your current balance is ₦{profile['balance']}")
    if profile["balance"] < MIN_WITHDRAWAL_NGN:
        print(f"[!] You can withdraw after reaching ₦{MIN_WITHDRAWAL_NGN}. Keep completing tasks.")
        return
    acct_name = input("Account name: ").strip()
    bank = input("Bank name: ").strip()
    acct_no = input("Account number: ").strip()
    amount_str = input(f"Amount to withdraw (≤ ₦{profile['balance']}): ").strip()
    try:
        amount = int(amount_str)
    except Exception:
        print("[!] Invalid amount.")
        return
    if amount <= 0 or amount > profile["balance"]:
        print("[!] Amount out of range.")
        return

    # Simulated processing
    print("[*] Processing your withdrawal request...")
    time.sleep(2)
    profile["balance"] -= amount
    update_user(users, profile)
    print(f"[✓] Withdrawal request submitted. New balance: ₦{profile['balance']}")
    log(f"Withdrawal requested: ₦{amount} to {acct_name} / {bank} / {acct_no}")


# ---------------- Main App ----------------
def main():
    ensure_dirs()
    users = None

    # Get or create profile
    profile, users = get_or_create_user()

    # If already activated, proceed; otherwise run activation
    if not profile.get("activated", False):
        print("\n--- Activation ---")
        activated = activation_flow(profile)
        if not activated:
            print("[!] Activation/verification failed or canceled. Exiting.")
            return
        # Mark activation
        profile["activated"] = True
        profile["activated_at"] = dt.datetime.now().isoformat()
        update_user(users, profile)
        print("[✓] Activation complete.\n")

    # Hawkit setup (creds)
    creds = setup_hawkit(profile)
    hawkit_user = creds["username"]

    # Main menu loop
    while True:
        print("\n==== Earnspree Menu ====")
        print("1) Start tasks now")
        print("2) Check balance / withdrawal")
        print("3) View referral info")
        print("4) Update Hawkit credentials")
        print("5) Exit")
        choice = input("Select an option (1-5): ").strip()

        if choice == "1":
            run_tasks(profile, hawkit_user)
            update_user(users, profile)

        elif choice == "2":
            print(f"\nBalance: ₦{profile['balance']}")
            if profile["balance"] >= MIN_WITHDRAWAL_NGN:
                ask = input("Do you want to request a withdrawal now? (y/n): ").strip().lower()
                if ask.startswith("y"):
                    withdraw_flow(profile, users)
                else:
                    print("[i] Okay. You can withdraw anytime after reaching the threshold.")
            else:
                short = MIN_WITHDRAWAL_NGN - profile["balance"]
                print(f"[i] You need ₦{short} more to reach the withdrawal threshold.")

        elif choice == "3":
            print("\n--- Referral ---")
            print("If you don’t have a Hawkit account yet, register using this link:")
            print(HAWKIT_REFERRAL_URL)

        elif choice == "4":
            print("\n--- Update Hawkit Credentials ---")
            haw_user = input("New Hawkit username: ").strip()
            haw_pass = getpass("New Hawkit password (hidden): ")
            save_hawkit_creds(profile["user_id"], haw_user, haw_pass)
            hawkit_user = haw_user
            print("[✓] Credentials updated.")

        elif choice == "5":
            print("\nThanks for using Earnspree!")
            break

        else:
            print("[!] Invalid choice. Please select 1-5.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[!] Interrupted. Bye.")
